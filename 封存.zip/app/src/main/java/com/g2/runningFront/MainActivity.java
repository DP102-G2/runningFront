package com.g2.runningFront;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.NavigationUI;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {
    private BottomNavigationView btbShop;
    private BottomNavigationView btbRun;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        holdNavigraph();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.option_menu, menu);
        return true;

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.opShop:
                btbShop.setVisibility(View.VISIBLE);
                btbRun.setVisibility(View.GONE);
                return true;
            case R.id.opRun:
                btbShop.setVisibility(View.GONE);
                btbRun.setVisibility(View.VISIBLE);
                return true;
            case R.id.opSetting:
                btbShop.setVisibility(View.GONE);
                btbRun.setVisibility(View.GONE);

        }
        return true;
    }

    private void holdNavigraph() {
        btbShop = findViewById(R.id.btbShop);
        NavController navCtrShop = Navigation.findNavController(MainActivity.this, R.id.nav_host_fragment);
        NavigationUI.setupWithNavController(btbShop, navCtrShop);

        btbRun = findViewById(R.id.btbRun);
        NavController navCtrRun = Navigation.findNavController(MainActivity.this, R.id.nav_host_fragment);
        NavigationUI.setupWithNavController(btbRun, navCtrRun);

        btbShop.setVisibility(View.GONE);

    }
}
